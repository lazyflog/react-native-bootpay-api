import { ViewProps } from 'react-native';
export interface BootpayTypesProps extends ViewProps {
    ios_application_id?: string;
    android_application_id?: string;
    onCancel?: (data: Object) => void;
    onError?: (data: Object) => void;
    onIssued?: (data: Object) => void;
    onConfirm?: (data: Object) => boolean;
    onDone?: (data: Object) => void;
    onClose?: () => void;
    payload?: Payload;
}
export declare class User {
    id?: string;
    username?: string;
    email?: string;
    gender?: number;
    birth?: string;
    phone?: string;
    area?: string;
    addr?: string;
}
export declare class Item {
    name?: string;
    qty?: number;
    id?: string;
    price?: number;
    cat1?: string;
    cat2?: string;
    cat3?: string;
}
export declare class StatItem {
    item_name?: string;
    item_img?: string;
    unique?: string;
    price?: number;
    cat1?: string;
    cat2?: string;
    cat3?: string;
}
export declare class Onestore {
    ad_id?: string;
    sim_operator?: string;
    installer_package_name?: string;
}
export declare class Extra {
    card_quota?: string;
    seller_name?: string;
    delivery_day?: number;
    locale?: string;
    offer_period?: string;
    display_cash_receipt?: boolean;
    deposit_expiration?: string;
    app_scheme?: string;
    use_card_point?: boolean;
    direct_card?: string;
    use_order_id?: boolean;
    international_card_only?: boolean;
    phone_carrier?: string;
    direct_app_card?: boolean;
    direct_samsungpay?: boolean;
    test_deposit?: boolean;
    enable_error_webhook?: boolean;
    separately_confirmed?: boolean;
    confirmOnlyRestApi?: boolean;
    open_type?: string;
    use_bootpay_inapp_sdk?: boolean;
    redirect_url?: string;
    display_success_result?: boolean;
    display_error_result?: boolean;
    disposable_cup_deposit?: number;
    use_welcomepayment?: number;
    first_subscription_comment?: string;
    except_card_companies?: [string];
    enable_easy_payments?: [string];
    confirmGraceSeconds?: number;
}
export declare class Payload {
    android_application_id?: string;
    ios_application_id?: string;
    pg?: string;
    method?: string;
    methods?: [string];
    order_name?: string;
    price?: number;
    tax_free?: number;
    order_id?: string;
    subscription_id?: string;
    authentication_id?: string;
    metadata?: Object;
    user_token?: string;
    extra?: Extra;
    user?: User;
    items?: [Item];
}
//# sourceMappingURL=BootpayTypes.d.ts.map