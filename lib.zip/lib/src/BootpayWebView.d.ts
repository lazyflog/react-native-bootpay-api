import React, { Component } from 'react';
import WebView, { WebViewMessageEvent } from 'react-native-webview-bootpay';
import { BootpayTypesProps } from './BootpayTypes';
export declare class BootpayWebView extends Component<BootpayTypesProps> {
    webView: React.RefObject<WebView<{}>>;
    state: {
        visibility: boolean;
        script: string;
        firstLoad: boolean;
        showCloseButton: boolean;
    };
    _VERSION: string;
    _DEBUG: boolean;
    dismiss: () => void;
    closeDismiss: () => void;
    onMessage: (event: WebViewMessageEvent) => void;
    onShouldStartLoadWithRequest: (_: string) => boolean;
    getSDKVersion: () => string;
    getEnvironmentMode: () => "" | "Bootpay.setEnvironmentMode('development');";
    getBootpayPlatform: () => "" | "Bootpay.setDevice('IOS');" | "Bootpay.setDevice('ANDROID');";
    transactionConfirm: () => void;
    removePaymentWindow: () => void;
    callJavaScript: (script: string) => void;
    getAnalyticsData: () => Promise<string>;
    confirm: () => string;
    done: () => string;
    issued: () => string;
    error: () => string;
    cancel: () => string;
    close: () => string;
    componentWillUnmount(): Promise<void>;
    componentDidMount(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=BootpayWebView.d.ts.map