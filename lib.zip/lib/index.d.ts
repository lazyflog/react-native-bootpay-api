import { BootpayModal } from './BootpayModal';
export { BootpayModal };
//# sourceMappingURL=index.d.ts.map